# THIS FILE IS GENERATED DURING THE SCIPY BUILD
# See tools/version_utils.py for details

short_version = '1.10.1'
version = '1.10.1'
full_version = '1.10.1'
git_revision = 'c1ed5ec'
commit_count = '2406'
release = True

if not release:
    version = full_version
